#include<iostream>

int main(){
    // for each loop is an alternative if iterating over an array by for loop .the syntax of foreach for()loop is :
    // for((dataype) (nameofthatvalue) : (datatypevariablename));
    
    // dont consider those inside close brackets

    // cout<<nameofthatvalue

    std::string family_members []={"Papa","Mummy","Arnav","Ankita","Golya","Maushi"};

    for (std::string members:family_members)
    {
        std::cout<<members<<'\n';
    }
    
    
}