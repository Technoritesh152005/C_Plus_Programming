#include<iostream>

double usdconversion(double ind_currency);
double pakistanconversion(double ind_currency);
double japanconversion(double ind_currency);
double russianconversion(double ind_currency);

int main(){

    double ind_currency=0;
    int choice;

    // running the program in do while loop
    do
    {
        std::cout<<"Enter the amount in Rupee to get converted : ";
    std::cin>>ind_currency;
    
        std::cout<<"Indian currency convertor\n";
    std::cout<<"Press 1 for USA currency converter\n";
    std::cout<<"Press 2 for PAKISTAN currency convertor \n";
    std::cout<<"Press 3 for JAPAN currency convertor\n";
    std::cout<<"Press 4 for RUSSIA convertor\n";
    std::cout<<"press 5 for exit\n\n";
    std::cin>>choice;
    switch (choice)
    {
        
    case 1:
        usdconversion(ind_currency);
        break;
        case 2:
        pakistanconversion(ind_currency);
        break;
        case 3:
        japanconversion(ind_currency);
        break;
        case 4:
        russianconversion(ind_currency);
    
    
    }
    } while (choice!=5);
    std::cout<<"The currency conversion calculator has been exited,THANKS FOR VISITING!\n";
    std::cout<<'\n'<<'\n';
    
}
double usdconversion(double ind_currency){
    double american_currency;
    american_currency=ind_currency*0.012;
    std::cout<<"The conversion to USD is : "<<american_currency<<" usd"<<'\n';
}
double pakistanconversion(double ind_currency){
    double pakistan_currency;
    pakistan_currency=ind_currency*3.32;
    std::cout<<"The conversion to pakistan currency is : "<<pakistan_currency<<" pakistan currency"<<'\n';
}
double japanconversion(double ind_currency){
    double japan_currency;
    japan_currency=ind_currency*1.83;
    std::cout<<"The conversion to japan currency is : "<<japan_currency<<" japanese yen"<<'\n';
}
double russianconversion(double ind_currency){
    double russian_currency;
    russian_currency=ind_currency*1.02;
    std::cout<<"The conversion to russian conversion is : "<<russian_currency<<" russian ruble"<<'\n';
}