#include <iostream>

int main() {
    int rows, columns;
    char symbol;
    using namespace std;
    // nested loop is loop inside loop

    cout << "Enter the number of rows: ";
    cin >> rows;
    cout << "Enter the number of columns: ";
    cin >> columns;
    cout << "Enter the symbol: ";
    cin >> symbol;

    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < columns; j++) {
            cout << symbol;
        }
        cout << '\n'; // Move to the next line after printing one row
    }

    return 0;
}
