#include<iostream>


std::string addstring( std::string firstname, std::string lastname);
// in parameters name can be given anything
// Jaha hum return statement use karte hain, waha void use nahi karna chahiye. void tab use hota hai jab function koi value return nahi karega.
int main(){
    std::string firstname;
    std::string lastname;
    std::string addstr;

    std::cout<<"enter your first name\n";
    std::cin>>firstname;
    std::cout<<"enter your last name\n";
    std::cin>>lastname;
    addstr = addstring(firstname,lastname);
    std::cout<<"The full name is : "<<addstr;


}
std::string addstring( std::string firstname, std::string lastname){
    return firstname+" "+lastname;
}
// jab hum return use karte hai tab woh datatype doh use joh woh return karega jessay int for whole and double for decimal numbers