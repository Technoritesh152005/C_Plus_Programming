#include<iostream>

int main(){

    std::string name ;
    std::cout<<"Please enter your full name\n";
    std::getline(std::cin,name);
    // Yes, name.length() (or equivalently name.size()) is used to check the length of the string, i.e., the number of characters it contains.
    if (name.length()>15)
    {
        std::cout<<"Please enter the character below 15 only\n";

    }
    else {
        std::cout<<"Welcome "<<name;
    }
}