#include<iostream>
enum day{sunday,monday,tuesday,thursday,friday,saturday};
// here sunday act as 0 automatic as index starts from zero.1 for monday,2 for tuesday

// day act as a kind of datatype
// Enums provide a set of named values, and you can use these named values in switch statements to handle different cases in a clear and organized way.

int main(){
    day weekday=monday;
  
    
    
switch (weekday)
{
case 0:std::cout<<"It is sunday<<"<<'\n';
    break;
case 1:std::cout<<"It is Monday<<"<<'\n';
    break;
case 2:std::cout<<"It is Tuesday<<"<<'\n';
    break;
case 3:std::cout<<"It is Wednesday<<"<<'\n';
    break;
case 4:std::cout<<"Its thursday"<<'\n';

default:std::cout<<"Invalid day"<<'\n';
    break;
}

}