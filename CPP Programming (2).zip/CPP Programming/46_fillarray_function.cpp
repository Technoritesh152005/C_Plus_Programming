// The fill function is used in programming to assign a specific value to a range of elements in a container, such as an array or a vector.
// it is used to store elements in array 

// std::fill(start, end, value);
// where start end is a value of _STRING
#include <iostream>
#include <algorithm>
#include <string>

int main() {
    const int size = 9;
    std::string name[size];

    std::fill(name, name + size / 3, "Pizza");
    std::fill(name + size / 3, name + 2 * (size / 3), "Hamburger");
    std::fill(name + 2 * (size / 3), name + size, "Butter chicken");

    for (const std::string& names : name) {
        std::cout << names << '\n';
    }

    return 0;
}
