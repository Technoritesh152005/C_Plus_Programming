#include<iostream>

int main(){
    int size=5;
    std::string family_members[size];
    std::string temp;

    for (int i = 0; i < size; i++)
    {
       std::cout<<"Enter your favourite person or you most loved person in this world,or else press 'q' to quit"<<'\n';
       std::getline(std::cin,temp);
       if (temp =="q"||temp=="Q")
       {
        break;
       }
       else{
            family_members[i]=temp;
       }
    }
    std::cout<<"Your favourite most loved person are:"<<'\n';
    for (int i = 0; i < size; i++)
    {
       if (!family_members[i].empty())
       {
        std::cout<<family_members[i]<<'\n';
       }
       else{
        break;
       }
    }
    
}