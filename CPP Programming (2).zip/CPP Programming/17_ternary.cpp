#include<iostream>

int main(){

    int number;
    printf("Enter the number\n");
    scanf("%d",&number);

    // ternary operator is a replacement of if,else if statement
    // syntax is condition ? expression 1 : expression 2;

    // grade>60? std::cout<<"Its pass":std::cout<<"Its not pass";
    number % 2==0 ? std::cout<<"Its even" : std::cout<<"Its odd";

    return 0;
}