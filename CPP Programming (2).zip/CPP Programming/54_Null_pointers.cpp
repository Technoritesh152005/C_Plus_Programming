
#include<iostream>

int main(){

    // A null pointer is a pointer that does not point to any valid memory location; it is typically set to nullptr (or NULL in older C++). It is used to indicate that the pointer is not currently assigned to any object or valid address. Use null pointers to initialize pointers safely and to check if a pointer has been assigned before dereferencing i
    
    // null pointer should be used when the pointer has been declared and not initialized as it will not assigned to some random memory
    
    int age=20;
    int x=25;
    int *ptr=&x;

    if (ptr==nullptr)
    {
        std::cout<<"The ptr is assigned to nullptr\n";
        
    }
    else{
     std::cout<<"It is not assigned";
    }

}