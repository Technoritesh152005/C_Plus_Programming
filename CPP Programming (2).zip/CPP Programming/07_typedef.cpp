#include<iostream>
#include<vector>

// typedef is a keyword which is used to create a new datatype of existing datatype.it helps if the datatype name is too large then we can replace it by another keyword and it act as same as of existing datatype

// The typedef keyword in C and C++ is used to create an alias for an existing data type. This can be particularly useful for simplifying complex type declarations or providing more meaningful names to existing types. When the type name is too lengthy or complex, typedef allows you to replace it with a simpler or more descriptive keyword, making the code easier to read and maintain. The new keyword acts exactly the same as the original data type.


typedef double dob;
typedef char character;

int main(){
    // int double;
    // so instead of using double we can use dob where dob act as a new existing dataype
    dob value_of_dob = 34;
    character name_of_character='$';
   std::cout<<"the value of dob in dataype double is :"<<value_of_dob<<std::endl;
   std::cout<<"the value of char in dataype character  is :"<<name_of_character<<std::endl;

}

