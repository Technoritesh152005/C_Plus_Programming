#include<iostream>

int main(){

    int temp;
    std::cout<<"Enter The temperature in fahrenheit\n";
    std::cin>>temp;
    

    // && also known as and operator executes the code if only both condition gets true
    if (temp>=95 && temp<=98)
    {
        std::cout<<"You are healthy and good to go\n";
        
    }
    else{
        std::cout<<"You are not good its better to consult\n";

    }

    // || also known as OR operator executes code if only one condition among them gets true
    if (temp<=95 || temp>=98)
    {
        std::cout<<"You are not good its better to consult\n";
    }
    else{
        std::cout<<"You are good my brother\n";
    }

    //  NOT opertor reverse the statement means the condition if its true it states false.also denoted by !
    bool beginner = false;

    // The ! (not) operator inverts the boolean value
    if (!beginner) {
        std::cout << "You are a beginner\n";
    } else {
        std::cout << "You are not a beginner\n";
    }


    
}