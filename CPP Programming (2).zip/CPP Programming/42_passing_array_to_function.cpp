// #include<iostream>

// int totalmarks(int marks[]);
// int main(){

//     int marks[]={45,56,67,78,89};
//     int totalmarks(int marks);
    
// }
// int totalmarks(int marks[]){
//     int total=0;
//     for (int i = 0; i < sizeof(marks)/sizeof(int); i++)
//     {
//         total=total+marks[i];
//     }
//     // /The size of the array cannot be determined inside the function totalmarks using sizeof(marks) because it only returns the size of the pointer, not the entire array.
//     return total;
//     std::cout<<total;
// }

#include<iostream>

int totalmarks(int marks[],int size);
int main(){

    int marks[]={77,66,88,85,79};
    int size=sizeof(marks)/sizeof(int);
    totalmarks(marks,size);
}
int totalmarks(int marks[],int size){
    int total=0;
    for (int i = 0; i < size; i++)
    {
        total+=marks[i];
    }
    std::cout<<total;
}

// when array is passed to function its parametrs must have [] so that each element can have access except it should not be given in function call