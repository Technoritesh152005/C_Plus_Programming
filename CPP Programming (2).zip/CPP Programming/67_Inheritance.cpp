#include<iostream>

    // Inheritance is the mechanism by which a new class (the derived class) acquires the properties and behaviors (attributes and methods) of an existing class (the base class). The derived class can extend or modify the functionality of the base class and can also have its own additional features.

    // parent class
    class Animal{
    public:
    bool jinda=true;

    void eat(){
        std::cout<<"These animal can also eat\n";
    }
    };

    // child class where it will have the properties of its parents class
    class Dog : public Animal{
    void bark(){
        std::cout<<"The dog goes bawh bawh\n";
    }
    };

    // child class where it will have the properties of its parents class
    class Cat : public Animal{
     void meow(){
        std::cout<<"The dog goes meow meow\n";
    }
};

int main(){
    Dog dog1;
    Cat cat1;

    std::cout<<dog1.jinda<<'\n';
    std::cout<<cat1.jinda<<'\n';

    dog1.eat();
    cat1.eat();
    return 0;
}