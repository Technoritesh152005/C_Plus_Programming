#include<iostream>

int main(){

    // cout is used to display what is to be given the information and
    // cin >> is used to give the information and store in particular datatype

    std::string name;
    int age;

    std::cout<<"what is your name"<<'\n';
    std::cin>>name;
    //  you encounter an issue with reading the full name using std::getline. This happens because std::cin >> name reads only a single word (until a space or newline), and the newline character left in the input buffer interferes with the subsequent std::getline call.
    
     std::cout<<"what is your full name"<<'\n';
    std::getline(std::cin>>std::ws,name);
     

    std::cout<<"what is your true age"<<'\n';
    std::cin>>age;

    std::cout<<"your name is : "<<name<<'\n';
    std::cout<<"your true age is  : "<<age<<'\n';
    std::cout<<"your name is : "<<name<<'\n';

    // The getline function in C++ is used to read an entire line from an input stream, including spaces. The syntax is as follows:
    //     std::getline(input_stream, string_variable);

   
return 0;

}