#include<iostream>

int main(){

    double num1;
    double num2;
    char op ;
    double result;

    std::cout<<"Enter your first number\n";
    std::cin>>num1;
        std::cout<<"enter the operator you choose\n";
        std::cin>>op;
            std::cout<<"Enter your second number\n";
            std::cin>>num2;

            switch (op)
            {
            case '+':
                result=num1+num2;
                std::cout<<"the addition gives : "<<result;
                break;
                case '-':
                result=num1-num2;
                std::cout<<"the subtraction gives : "<<result;
                break;
                case '*':
                result=num1*num2;
                std::cout<<"the multiplication gives : "<<result;
                break;
                case '/':
                result=num1/num2;
                std::cout<<"the division gives : "<<result;
                break;
            
            default:
            std::cout<<"Please enter a valid operator\n";
                break;
            }
}