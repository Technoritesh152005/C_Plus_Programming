#include<iostream>
#include<time.h>

int main(){
    using namespace std;
    srand(time(NULL));
    int randNum=rand()%7+1;
    string name;

    cout<<"Enter start to start the game\n";
    cin>>name;
    if (name == "start"|| name =="START")
    {
        switch (randNum)
    {
    case 0
       :cout<<"You won pizza\n";
        break;
        case 1
       :cout<<"You won free visa to pakistan\n";
        break;
        case 2
       :cout<<"You won mobile  \n";
        break;
        case 3
       :cout<<"You won butter chicken\n";
        break;
        case 4
       :cout<<"You won movie ticket\n";
        break;
        case 5
       :cout<<"You won free subscription of netflix\n";
        break;
        case 6
       :cout<<"You won laptop\n";
        break;
    }
    
    }
    else{
        cout<<"Please enter start\n";
    }

}