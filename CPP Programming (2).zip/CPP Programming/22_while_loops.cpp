#include<iostream>
    // A while loop is a control flow statement that repeatedly executes a block of code as long as a specified condition is true.
    // if condition meets true it keeps on going executing the code
int main(){
    using namespace std;
    int a =1;
    string name;
    while (name.empty())
    {
        cout<<"Enter your name SIR\n";
        getline(cin,name);
    }
    cout<<"hello "<<name;

    while ( a==1)
    {
        cout<<"This is an infinite loop cause this condition will never get false\n";
    }
    
}