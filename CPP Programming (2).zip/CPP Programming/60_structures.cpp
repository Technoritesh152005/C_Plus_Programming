// struct = it is a structure ehich group related variable name under struct like datatype of int double float char bool

#include<iostream>
// member can be accesed by using . (class member access operator)

struct student
{
    std::string name;
    int age;
    double cgpa;

};

int main(){

    student students[5];
    for (int i = 0; i < 5; i++)
    {
        std::cout<<"What is the name for student "<< i+1<<'\n';
        std::cin>>students[i].name;
        std::cout<<"What is the age for student "<< i+1<<'\n';
        std::cin>>students[i].age;
        std::cout<<"What is the cgpa for student "<< i+1<<'\n';
        std::cin>>students[1].cgpa;
    }

    std::cout<<"HERE ARE THE FOLLOWING DETAILS OF STUDENT";

    for (int i = 0; i < 5; i++)
    {
       std::cout<<"The name of student "<< i+1<<" is"<< students[i].name<<'\n';
       std::cout<<"The age for student "<< i+1<<" is"<< students[i].age<<'\n';
       std::cout<<"The cgpa of student "<< i+1<<" is"<< students[i].cgpa<<'\n';
    }
    
    


}