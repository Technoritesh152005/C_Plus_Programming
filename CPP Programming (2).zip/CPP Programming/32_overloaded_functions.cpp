#include<iostream>
void bakepizza();
void bakepizza(std::string toppings1);
void bakepizza(std::string toppings1,std::string toppings2);
// Function overloading can make your code more readable and intuitive. Instead of having different function names for slightly different tasks, you can use the same name with different parameters.it is a function with same name but different parameters
int main(){

    bakepizza();
    bakepizza("pepporoni");
    bakepizza("pepporoni,mushroom ");
}

void bakepizza(){
    std::cout<<"Here is ur plane pizza"<<std::endl;
}
void bakepizza(std::string toppings1){
    std::cout<<"Here is ur  :"<<toppings1<<"pizza"<<'\n';
}
void bakepizza(std::string toppings1,std::string toppings2){
    std::cout<<"Here is ur : "<<toppings1<<toppings2<<" pizza"<<'\n';
}