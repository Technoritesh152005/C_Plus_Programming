#include<iostream>

int main(){

        int month;
        // A switch statement is a control flow statement that allows a variable to be tested for equality against a list of values. Each value is called a case, and the variable being switched on is checked for each case. If a match is found, the corresponding block of code is executed.

        std::cout<<"enter the number between 1 to 12"<<std::endl;
        std::cin>>month;

        switch (month)
        {
        case 1:
            std::cout<<"ITS JANUARY"<<'\n';
            break;
            case 2:
            std::cout<<"ITS FEBRUARY"<<'\n';
            break;
            case 3:
            std::cout<<"ITS MARCH"<<'\n';
            break;
            case 4:
            std::cout<<"ITS APRIL"<<'\n';
            break;
            case 5:
            std::cout<<"ITS MAY"<<'\n';
            break;
            case 6:
            std::cout<<"ITS JUNE"<<'\n';
            break;
            case 7:
            std::cout<<"ITS JULY"<<'\n';
            break;
            case 8:
            std::cout<<"ITS AUGUST"<<'\n';
            break;
            case 9:
            std::cout<<"ITS SEPTEMBER"<<'\n';
            break;
            case 10:
            std::cout<<"ITS OCTOBER"<<'\n';
            break;
            case 11:
            std::cout<<"ITS NOVEMBER"<<'\n';
            break;
            case 12:
            std::cout<<"ITS DECEMBER"<<'\n';
            break;
        
        default:
        std::cout<<"PLEASE ENTER A VALUE BETWEEN 1 TO 12 ONLY "<<'\n';
            break;
            
        }
}