#include<iostream>

// A namespace is like a container that holds a set of names. These names could be for variables, functions, classes, etc. Namespaces help to organize code and prevent naming conflicts.it is used to avoid name collision and use readability


namespace first{
    int x=1;
}
namespace second{
    int x=2;
}
int main(){

    using namespace first;

    std::cout<<"the value of x in namespace first is "<<x<<std::endl;
    // from this it allows not to write prefix or name of naespace
     using namespace second;

    // std::cout<<"the value of x in namespace second is "<< x <<std::endl;
    // you cannot use using namespace for two namespaces that contain variables (or functions, classes, etc.) with the same name because it causes ambiguity for the compiler. When both namespaces are brought into the global scope using using namespace, the compiler cannot determine which variable you are referring to if they have the same name.

}
// here it is also given for reference that std if used using naespace then no need to add during printing it..
// using namespace std;

//     cout<<"the value of x in namespace first is "<<first::x<<std::endl;