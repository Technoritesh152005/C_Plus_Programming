#include<iostream>

    // dynamic memory is the memory that is allocated after the program is already compiled or executed
int main(){

    int *ptr=NULL;

    // here new returns the adress to ptr which will store value of int datatype
    // the new operator allocates memory on the heap and returns a pointer to the beginning of that allocated memory. This pointer can then be used to access and manipulate the allocated memory.

    ptr = new int;
    *ptr=21;

    std::cout<<"Adress : "<<ptr<<'\n';
    std::cout<<"Value : "<<*ptr<<'\n';

   
    delete ptr;
    // Deleting dynamically allocated memory is crucial to:

    // Prevent memory leaks.
    // Ensure efficient memory usage.
    // Avoid undefined behavior.

     return 0;
}