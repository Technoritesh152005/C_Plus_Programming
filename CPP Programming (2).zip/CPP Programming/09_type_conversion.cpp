#include<iostream>

int main(){

    int correct =(double)3.24;
    // (this is a type of explicit type conversion)
    int question=10;
    // the line 5 and 6 is a type of implicit type conversion means directly giving the datatype to it
    float result = (correct/(float)question)*100;
    // line 8 is a type of explicit 

    std::cout<<"the score in percentage is : "<<result<<"%"<<std::endl;
    std::cout<<"the vallue in correct is : "<<correct<<std::endl;
}