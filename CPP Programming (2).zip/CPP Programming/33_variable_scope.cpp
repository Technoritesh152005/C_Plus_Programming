#include<iostream>
void printnum(int num);
int main(){

   std::cout<<"****************one part of code***************\n";
    int num=3;
    // here num is a global variable of main function so we need to add parameters and arguments to the function
    printnum(num);
    std::cout<<"****************one part of code*************"<<'\n'<<'\n';


}
void printnum(int num){
    std::cout<<num<<'\n';
}

#include<iostream>
void printmynum();

int main(){
    int mynum=3;
    printmynum();
}
void printmynum(){
    int mynum=5;
    std::cout<<"the value from function is : "<<mynum;
    
}
// Passing values from main to a function: Define parameters in the function and pass arguments from main.

// Using local variables in a function: Simply define and use the local variables within the function. No need for arguments or parameters.