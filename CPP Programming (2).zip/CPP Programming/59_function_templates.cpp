#include<iostream>
template < typename T,typename U>
    // A function template in C++ allows you to create a single function definition that works with different data types. 
    // here T acts as a datatype that will take int and U as a double datatype 

auto max(T a,U b){
    if (a>b)
    {
        std::cout<<a<<'\n';
    }
    else {
        std::cout<<b<<'\n';
    }
}
int main(){

    max(3,4.5);
    
    return 0;
}

