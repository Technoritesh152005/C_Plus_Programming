#include<iostream>
void printinfo(const std::string name, const int age);
int main(){

    std::string name="ritesh";
    int age=15;
    printinfo(name,age);
    
}
void printinfo(  const std::string name, const int age){
    // name="chaman";
    // age=10;
    std::cout<<name<<'\n';
    std::cout<<age<<'\n';

    
}
// Const Parameters:

// Purpose: Ensure function arguments are not modified.
// Use with Pass-by-Value: Protect local copies from modification.
// Use with Pass-by-Reference: Avoid copying large objects and ensure they remain read-only.
// if you declare function parameters as const, you cannot modify them within the function. Here’s how const parameters work and why you see an issue in your code: