// Syntax: using new_type_name = existing_type;
// using also act as typdef but most commonly used 

#include<iostream>

    using integer=int;
    
    // here int was acting a old datatype which is replaced by new datatype called integer
    // and now as integer is acting as a datatype it is given a variable called value to store the data in it
int main(){

    integer value =45;
}