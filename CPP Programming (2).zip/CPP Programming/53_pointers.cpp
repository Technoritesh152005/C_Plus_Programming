#include<iostream>

int main(){
    // pointer:it acts like a variable which store the memory adress of another variable 
    // & is used for adress of that __value
    // and * is used to access the value of that variable

    // in all cases, you need to use the * symbol when declaring a pointer in C++
    


    int age=21;
    std::string name[3]={"arnav","papa","mummy"};
    
    // when we declare pointer remember to take datatype same as of that variable
    int *Page=&age;
    std::string *pname=name;

    std::cout<<*Page<<'\n';
    std::cout<<pname[0]<<'\n';


}