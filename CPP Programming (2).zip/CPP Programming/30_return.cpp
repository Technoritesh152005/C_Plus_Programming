#include<iostream>

double area(double length);
double cube(double length);
int main(){

    double length,area_value,volume;


    std::cout<<"Enter the value of length\n";
    std::cin>>length;

    area_value=area(length);
    std::cout<<"The value of area is : "<<area_value<<"cm2"<<'\n';

    volume=cube(length);
    std::cout<<"The volume of a cube is : "<<volume<<'\n';

    
    return 0;
}

double area(double length){
    return length*length;
}
double cube(double length){
    return length*length*length;
}