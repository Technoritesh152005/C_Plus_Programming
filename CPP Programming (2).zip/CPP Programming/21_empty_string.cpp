#include<iostream>

int main(){
   char character_at_index_3;
    std::string name ;
    std::cout<<"Please enter your full name\n";
    std::getline(std::cin,name);

    // name.empty() in C++ is to check if the std::string object name is empty, meaning it contains no characters. 
    if (name.empty())
    {
        std::cout<<"Please enter your name you didnt enter a character\n";
    }
    else{
        std::cout<<"Hello bro "<<name;
    }


    // he name.clear() method in C++ is used to remove all characters from the std::string object name, effectively making it an empty string. This method does not change the capacity of the string, but it does set its length to zero.
    name.clear();
    std::cout<<"Hello bro ur name is : "<<name;

    // he name.append() method in C++ is used to add or concatenate additional characters or another string to the end of the std::string object name. This method modifies the original string by appending the specified content.
   
    std::cout<<"Please enter your username\n";
    std::cin>>name;
     name.append("@outlook.com");

    std::cout<<"Your username will be : "<<name<<std::endl;
    // The name.at() method in C++ is used to access a character at a specific position in a std::string object. I..the name.at()gives the character return when we point out its index in the parenthesis
    character_at_index_3=name.at(3);
    std::cout<<"The character at 3rd index will be :\n"<<character_at_index_3;

    // name.insert(position of index,"content")it is used to insert a character to a string by giving it a index position
    name.insert(0,"@");
    std::cout<<"you are :"<<name;

    // name.find is a property where it finds particular any character and returns its index
    std::cout<<name.find(' ');

    name.erase(0,3);
    std::cout<<"The name when erased from index 0 to 3 will be :"<<name;
    
}
