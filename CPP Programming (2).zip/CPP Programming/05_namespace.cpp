
#include<iostream>
// Yes, namespaces allow us to create multiple variables with the same name without conflict, as long as they exist in different namespaces.
namespace my_age{
    int a =20;
}

namespace other_age{
    int b=33;
}
int main(){

    int a =15;
     int b=22;

     std::cout<<"tha value of a before using namespace is :"<<a<<std::endl;
     std::cout<<"tha value of b before using namespace is :"<<b<<std::endl;

     std::cout<<"************************"<<std::endl;

     std::cout<<"the age in my_age of namespace will be : "<<my_age::a<<std::endl;
     std::cout<<"the age in other_age of namespace will be : "<<other_age::b<<std::endl;

}