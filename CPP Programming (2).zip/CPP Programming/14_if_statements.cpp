#include<iostream>

int main(){

    int age;

    std::cout<<"Enter your age"<<'\n';
    std::cin>>age;

    // if is a conditional instrument that if a condition is a true then perform sets of code otherwise dont perform it
    if (age>=18 && age <72)
    {
        std::cout<<"Yours age is above 18 and you can drive"<<'\n';
    }
    else if (age<0)
    {
        std::cout<<"you are still not born my baby"<<'\n';
    }
    else{
        std::cout<<"enter a valid number"<<std::endl;
    }


}