#include<iostream>

    // dynamic memory allocation allows you to allocate exactly the amount of memory needed at runtime, which helps prevent memory waste. This is particularly useful when the required memory size is not known until the program is running.

    // it is useful when we dont know how much memory will __need

int main(){

    char *gradeptr=NULL;
    int size;

    std::cout<<"Enter the size: "<<'\n';
    std::cin>>size;

    gradeptr=new char[size];

    for (int i = 0; i < size; i++)
    {
        std::cout<<"Enter the grade for"<< i+1<<'\n';
        std::cin>>gradeptr[i];
        std::cout<<'\n';
    }
    for (int i = 0; i < size; i++)
    {
       std::cout<<gradeptr[i]<<'\n';
    }
    delete[] gradeptr;
}