#include<iostream>

    // function prototypes
    int sumevendigit(std::string cardnumber);
    int sumodddigit(std::string cardnumber);

int main(){

    // declaration of string of cardnumber
    // so each value act as character acc to ascii tablen
    std::string cardnumber ;
    std::cout<<"Please enter a valid credit card number"<<std::endl;
    std::cin>>cardnumber;

    // function call
    int result=sumevendigit(cardnumber)+sumodddigit(cardnumber);

    // prcocedure to check whether it is valid or not
    if (result%10==0)
    {   std::cout<<"**************Result*************"<<'\n';
       std::cout<<"The card number:"<< cardnumber<<" is valid"<<std::endl;
       std::cout<<"**********************************'\n";
    }
    else{
        std::cout<<"It is  INVALID\n";
    }
    
    
    
    

}

int sumevendigit(std::string cardnumber){
    // initializing sum to zero
    int sum=0;
    // for even digit sum they are seperated from last 2nd digit
    for (int i = cardnumber.size()-2; i >=0; i-=2)
    {   
        // converting charc to a  numeric value 
        int digit=cardnumber[i]-'0';
        // for even digit doubling it
        int doubled =digit*2;

        if (doubled>9)
        {
            doubled=doubled-9;
        }
        sum=sum+doubled;

        
    }
    return sum;
}
int sumodddigit(std::string cardnumber){

     int sum=0;
    for (int i = cardnumber.size()-1; i >=0; i-=2)
    {
        int digit=cardnumber[i]-'0';
       
        sum=sum+digit;
    }
    return sum;
}
// each digit in a string is treated as a character. For example, in the string "4532015112830366", each digit '4', '5', '3', etc., is a character, not a numerical value.