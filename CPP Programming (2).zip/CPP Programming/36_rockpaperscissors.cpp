#include <iostream>
#include <ctime>

    using namespace std;

int rockpaperscissors(char you, char comp);

int main() {

    char comp, you;

    do {
        cout << "Welcome to the rock paper and scissors game\n";
        cout << "Press 'r' for rock\n";
        cout << "Press 's' for scissor\n";
        cout << "Press 'p' for paper\n";
        cout << "Press 'e' for exit\n ";
        cin >> you;

        if (you == 'e' || you == 'E') {
            break;
        }

        if (you != 'r' && you != 'p' && you != 's') {
            cout << "Invalid input! Please enter 'r', 'p', 's', or 'e'." << endl;
            continue;
        }

        srand(time(NULL));
        int number = (rand() % 3) + 1;

        if (number == 1) {
            comp = 'r';
        } else if (number == 2) {
            comp = 'p';
        } else {
            comp = 's';
        }

        int result = rockpaperscissors(you, comp);

        if (result == 0) {
            cout << "THE MATCH HAS BEEN DRAW, TRY AGAIN!" << '\n';
        } else if (result == 1) {
            cout << "CONGRATULATIONS, YOU HAVE WON THE MATCH" << '\n';
        } else if (result == -1) {
            cout << "YOU LOSE, TRY ONCE AGAIN" << '\n';
        }
    } while (true);

    return 0;
}

int rockpaperscissors(char you, char comp) {

    if (you == comp) {
        return 0;
    }
    // cases that will occur
    // rs, rp, pr, ps, sr, sp
    if (you == 'r' && comp == 's') {
        return 1;
    } else if (you == 'r' && comp == 'p') {
        return -1;
    } else if (you == 'p' && comp == 'r') {
        return 1;
    } else if (you == 'p' && comp == 's') {
        return -1;
    } else if (you == 's' && comp == 'r') {
        return -1;
    } else if (you == 's' && comp == 'p') {
        return 1;
    }

    // Default return statement if none of the above conditions are met
    return 0;
}
