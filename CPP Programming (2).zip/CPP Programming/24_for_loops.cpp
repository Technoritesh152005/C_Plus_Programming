#include<iostream>

int main(){
    
    // A for loop is a control flow statement that allows code to be executed repeatedly based on a given condition. I
   
    std::string name;
    std::cout<<"enter your content\n";
    std::getline(std::cin,name);

    for (int i = 0; i < 100; i++)
    {
        std::cout<<name<<'\n';
    }
    // for (int  i = 0; i <100; i+=2)
    // {
    //     std::cout<<i<<'\n';
    // }
    
    
}
