#include <iostream>

int main()
{
    int age;
    // variable declaration
    age = 19;
    // variable assigned
    int date = 17;
    int year = 2024;
    int month = 7;

    // int is a datatype which is used to store a integer whole number value and here date,year and month is a variable which storesthe data int type to it

    std::cout << age << std::endl;
    std::cout << date << std::endl;
    std::cout << year << std::endl;
    std::cout << month << std::endl;

    return 0;
}