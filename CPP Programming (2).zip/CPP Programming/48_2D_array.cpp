//  2D array, or two-dimensional array, is a type of array that organizes data in a grid format with rows and columns.
// it act like a type of array which can store multiple array;

#include<iostream>

int main(){

    std::string foods[][3]={
                                {"butter_chicken","Pizza","Shwarma"},
                                {"Bangda","Icecream","Samosa"},
                                {"lays","Kurkure","7up"}
                           };
  int rows=sizeof(foods)/sizeof(foods[0]);
  int columns=sizeof(foods[0])/sizeof(foods[0][0]);

  for (int i = 0; i < rows; i++)
  {
    for (int j = 0; j < columns; j++)
    {
        std::cout<<foods[i][j]<<' ';
    }
    std::cout<<'\n';
  }
                           
}
// }it is not strictly necessary to provide a size for the first dimension (the number of rows) when you initialize a 2D array in C++. The compiler can infer the size of the first dimension from the initialization data.

// when initializing a 2D array, you use multiple sets of curly brackets to define each row. The additional curly brackets help to group the elements of each row together.