#include<iostream>

int main(){

    int total_students=40;


    // arithmetic operations for additions
    // total_students=total_students+1;
    // total_students+=1;
    // total_students++;
  
    // arithmetic operations for subtractions
    // total_students=total_students-5;
    // total_students-=6;
    // total_students--;

    // arithmetic operations for multiplication
    // total_students=total_students*2;
    // total_students*=2;


    // arithmetic operation for division
    // total_students=total_students/5;
    //  total_students/=2;

    // to get the remainder we use modulus operator

    // total_students=total_students%5;
    // this means that the 40 members of group is divided into 5 and all the students are in the grp and no one is left
      std::cout<<"the value is :"<<total_students<<std::endl;
}