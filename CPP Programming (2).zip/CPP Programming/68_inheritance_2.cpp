#include<iostream>

    class Shape{
        public:
        double volume;
        double side;
        double radius;
    };

    class Cube : public Shape{
        public:

        Cube(double side){
            this->side=side;
            volume=side*side*side;
        }
            
    };
    class Sphere : public Shape{
        public:

        Sphere(double radius ){
            this->radius=radius;
            volume=(4.0/3.0)*3.14159*radius*radius*radius;

        }
    };

int main(){

    Cube cube(10.0);
    Sphere sphere(23);

    std::cout<<"volume of cube is: "<<cube.volume<<'\n';
    std::cout<<"Volume of sphere is: "<<sphere.volume<<'\n';


    return 0;
}