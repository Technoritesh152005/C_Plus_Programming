
#include<iostream>
void balance_enquiry(double balance);
void deposit_amount(double &balance);
void withdraw_amount(double &balance);
int main(){
    double balance=0;
    int choices;

    do
    {
        std::cout<<"*************************\n\n";
    std::cout<<"Enter the choices\n";
    std::cout<<"Press 1 for balance enquiry\n";
    std::cout<<"Press 2 for depositing money\n ";
    std::cout<<"Press 3 for withdrawing money\n";
    std::cout<<"Press 4 for exit\n";
    std::cin>>choices;
    std::cout<<"*************************\n\n";

    switch (choices)
    {
    case 1:balance_enquiry(balance);
        break;
        case 2:deposit_amount(balance);
             break;
             case 3:withdraw_amount(balance);
                  break; 
    
                    default:std::cout<<"Invalid choice";
                        break;
    }
    } while (choices!=4);

    std::cout<<"Thanks for visiting !\n";
    
    
}
void balance_enquiry(double balance){
std::cout<<"The balance is : "<<balance<<'\n';
}
void deposit_amount(double &balance){
    double deposit;
    std::cout<<"Enter the amount you need to deposit\n";
    std::cin>>deposit;
    balance+=deposit;
    std::cout<<"The amount has been deposited of : "<<deposit<<'\n';
    std::cout<<"The balance after depositing is : "<<balance<<'\n';
}
void withdraw_amount(double &balance){
    double withdraw;
    std::cout<<"Enter the amount you need to withdraw\n";
    std::cin>>withdraw;
    if (balance>withdraw)
    {   balance-=withdraw;
        std::cout<<"The amount has been withdraw of : "<<withdraw<<'\n';
        std::cout<<"The balance after withdrawing is : "<<balance<<'\n';
    }
    else{
        std::cout<<"Insufficient funds\n";
    }
}
// The & symbol in function parameters denotes a reference, which means the function works with the actual variable passed to it, not a copy. This allows the function to directly modify the variable's value in the caller's scope. In your code, it's used to update the balance variable when depositing or withdrawing money.