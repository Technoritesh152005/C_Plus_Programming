#include<iostream>

int main(){

     int students=6-(4+3)*7/5;
    //  6-4+21/5
    //  6-4+4
    //  2+4;
    // 6-7*7/5
    // 6-49/5
    // 6-9

    // priority order 
    // parenthesis
    // multiplication and division
    // addition and subtraction
    std::cout<<"the value of students is : "<<students<<std::endl;
}