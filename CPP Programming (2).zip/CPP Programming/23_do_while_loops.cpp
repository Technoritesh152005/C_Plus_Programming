#include<iostream>

int main(){

    int num;
    do
    {
        std::cout<<"enter a +ve number\n";
        std::cin>>num;

    } while (num <0);
    // do while loop is a loop which will run the code atleast once and then checks the condition.
    // REMINDER : Till we dont get the condition false the loops go on running and when the condition gets meet the loops gets exit 
    
}