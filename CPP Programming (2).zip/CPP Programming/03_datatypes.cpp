
#include <stdio.h>
#define Max 5  // Define the maximum size of the stack

int stack[Max];
int TOP = -1;

// Push operation
void push(int value) {
    if (TOP == Max - 1) {
        printf("Stack Overflow! Cannot push %d\n", value);
    } else {
        TOP++;
        stack[TOP] = value;
        printf("Pushed %d into stack\n", value);
    }
}

// Pop operation
void pop() {
    if (TOP == -1) {
        printf("Stack Underflow! Cannot pop\n");
    } else {
        printf("Popped %d from stack\n", stack[TOP]);
        TOP--;
    }
}

// Show operation
void show() {
    if (TOP == -1) {
        printf("Stack is empty.\n");
    } else {
        printf("Stack elements are:\n");
        for (int i = TOP; i >= 0; i--) {
            printf("%d\n", stack[i]);
        }
    }
}

// Main function
int main() {
    int choice, value;

    while (1) {
        printf("\nStack Operations:\n");
        printf("1. Push\n");
        printf("2. Pop\n");
        printf("3. Show\n");
        printf("4. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Enter value to push: ");
                scanf("%d", &value);
                push(value);
                break;

            case 2:
                pop();
                break;

            case 3:
                show();
                break;

            case 4:
                printf("Exiting...\n");
                return 0;

            default:
                printf("Invalid choice. Please try again.\n");
        }
    }
}
