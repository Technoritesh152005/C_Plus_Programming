#include <iostream>

int main() {
    // sizeof() operator determines the size in bytes of a variable, datatype, class, or object
    float marks = 66.5;  
    // 4 bytes
    double gpa =8.9;
    // 8 bytes
    char grade='F';
    // one character takes one bytes
    bool student =true;
    // 1 bytes
    char aplhabets[]={'a','b','c','d'};
    // 4 bytes
    std::string car[]={"Lambhorgini","ferrari"};
    
    
    std::cout << sizeof(car) << " bytes\n";

    // from size of operator we can calculate the no of elemnts in array
    std::cout<<sizeof(aplhabets)/sizeof(char)<<" elements\n";

    return 0; 
}
