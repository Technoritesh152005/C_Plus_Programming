#include<iostream>

int main(){

    // constant : it is a keyword where we cannot modify its value in any circumstances

    // double pi =3.145;
    // pi=45;
    // // here as pi value is changed so the circumference is also changed.. the circumference after modification is 900
    // double radius1 = 10;
    // double circumference = 2*pi*radius1;

    // std::cout<< "the circumference will be "<<circumference;

    // **********************************

    const double PIE =3.145;
    // PIE = 31.4;
    // it gives error that pie cannot be changed as its a constant value
    // here as pi value is changed so the circumference is also changed.. the circumference after modification is 900
    double radius2 = 10;
    double circumference = 2*PIE*radius2;

    std::cout<< "the circumference will be "<<circumference<<"cm";

}