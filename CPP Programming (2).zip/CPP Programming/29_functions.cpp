#include<iostream>
// function is a block of reusable code
void happybirthday(std::string name,int age);
// function declaration
// If you want to create a function that performs an action, like displaying a message, but does not return any value, you would use void as the return type of the function

int main(){
    std::string name;
    // std::cout<<"enter your name\n";
    // std::getline(std::cin,name);
    int age=20;

    happybirthday("Ritesh",20);
   
    // function call
}
// Scope of Variables: The variable name is declared inside the main function, so it is not accessible in the happybirthday function. To fix this, you can pass name as an argument to the happybirthday function.think main function as a ur house and function as ur neighbour house.a neighbour house wont knew what is going on ur house , so u must pass a argument of datatpe to function call
// the happybirthday function now takes a const std::string name (parameter)to accept the name.
void happybirthday(std::string name,int age){
    std::cout<<"Happy birthday to u  "<<name<<'\n';
    std::cout<<"Happy birthday to you at ur age : "<<age<<'\n';
    std::cout<<"Happy birthay dear"<<name<<'\n';
     std::cout<<"you are "<<age<<"years old\n";

}