#include<iostream>
#include<cmath>

int main(){

    double x = 5.5;
    double y = 9;
    double z;

    // z=std::max(x,y);
    // max function is used to compare two max value
    // z=std::min(x,y);
    // min function is used to compare two max value
    z= pow(2,3);
    // z=sqrt(9);
    // z=round(x);
    // z=abs(-5);


    std::cout<< z;

}