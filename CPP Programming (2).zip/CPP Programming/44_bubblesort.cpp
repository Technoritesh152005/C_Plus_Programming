#include <iostream>
int sortarray(int number_array[], int size);
// function prototype
int main()
{

    int number_array[] = {1, 5, 3, 9, 7, 8, 2, 6, 4, 10};
    // array is created of numbers
    int size = sizeof(number_array) / sizeof(number_array[0]);
    sortarray(number_array, size);
    // function call

    for (int i = 0; i < size; i++)

    {
        std::cout << number_array[i] << ' ';
    }

    return 0;
}
int sortarray(int number_array[], int size)
{

    int temp = 0;
    // a temporary null file
    // moving the first for loop till size-1 cause the last element will place its own position automatically. the last element will gets ordered first as a higher element
    for (int i = 0; i < size - 1; i++)
    {
        for (int j = 0; j < size - i - 1; j++)
        {
            if (number_array[j] > number_array[j + 1])
            {
                temp = number_array[j];
                number_array[j] = number_array[j + 1];
                number_array[j + 1] = temp;
            }
        }
        // moving the second file till size-i-1
        // cause we dont need to swap those number again which are already swap
    }
}