#include <iostream>

// Function to search for a number in an array
int searchnumber(int numbers[], int size, int number);

int main() {
    // Array of numbers
    int numbers[] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 0};
    int size = sizeof(numbers) / sizeof(numbers[0]); // Calculate the size of the array

    int number;
    std::cout << "Enter a number you need to search:\n";
    std::cin >> number; // Get the number to search from the user

    int index = searchnumber(numbers, size, number); // Search for the number

    // Output the result
    if (index != -1) {
        std::cout << "The element " << number << " has an index of " << index << '\n';
    } else {
        std::cout << "The number is not in the array \n";
    }

    return 0;
}

// Function to search for a number in the array
int searchnumber(int numbers[], int size, int number) {
    // this perform linear search where it check and access all one by one elements
    for (int i = 0; i < size; i++) {
        if (numbers[i] == number) {
            return i; // Return the index if the number is found
        }
    }
    return -1; // Return -1 if the number is not found
}
