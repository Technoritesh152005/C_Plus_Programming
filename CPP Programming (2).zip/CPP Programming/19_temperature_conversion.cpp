#include<iostream>

int main(){

    float celcius , fahrenheit;
    char unit;

    std::cout<<"************** WELCOME TO TEMPERATURE CONVERSION PROGRAM*************\n";

    std::cout<<"Enter C for celcius and F for fahrenheit\n";
    std::cout<<"Enter the temperature you want to change it\n";
    std::cin>>unit;

    if (unit == 'F' || unit == 'f')
    {
        std::cout<<"Enter the temperature\n";
        std::cin>>fahrenheit;
        celcius=(fahrenheit-32)/1.8;
        std::cout<<"The temperature in celcius will be : "<<celcius<<std::endl;
    }
    else if (unit == 'C' || unit == 'c')
    {
        std::cout<<"Enter the temperature\n";
        std::cin>>celcius;
        fahrenheit=(celcius*1.8)+32;
        std::cout<<"The temperature in fahrenheit will be : "<<fahrenheit<<std::endl;
    }
    else{
        std::cout<<"Please enter a valid response\n";
    }
    

    std::cout<<"***********************************************************************\n";
}