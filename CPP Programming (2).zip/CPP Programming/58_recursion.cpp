#include<iostream>

int factorial(int num);

int main(){

    int num;
    std::cout<<"Enter the number you want factorial: "<<'\n';
    std::cin>>num;

   int res= factorial(num);
   std::cout<<"The factorial of : "<<num<<"is : "<<res<<'\n';


}

//   iterative method== mostly uses loops

int factorial(int num){
    int result=1;
    for (int i = 1; i <= num; i++)
    {
        result=result*i;
    }
   return result;
}

// recursive method== invoking function multiple times
int factorial(int num){
    int result;
   if (num>1)
   {
    return num*factorial(num-1);
   }
   
}
    