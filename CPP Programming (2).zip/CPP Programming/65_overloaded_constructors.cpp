#include<iostream>

// Overloaded constructors are multiple constructors within the same class that have the same name but different parameters (number or type). They allow creating objects in different ways by passing different sets of arguments during object creation.
class Pizza{
    public:

    std::string topping1;
    std::string topping2;


// constructors:
    Pizza( std::string topping1){
        this->topping1=topping1;
    }
    Pizza( std::string topping1,std::string topping2){
        this->topping1=topping1;
        this->topping2=topping2;
    }

};

int main(){

    Pizza pizza1("peperooni");
    Pizza pizza2("peperonni"," mushroom");


    std::cout<<pizza1.topping1<<'\n';
    std::cout<<pizza2.topping1<< pizza2.topping2<<'\n';
}