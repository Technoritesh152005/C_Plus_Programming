#include<iostream>
struct CAR
{
   std::string model;
   int year;
};
// here car is a nickname or any variable you want to declare
void printfxn(CAR car);
int main(){

    CAR car1;
    CAR car2;
    car1.model="BMW";
    car1.year=2024;
    std::cout<<&car1<<'\n';
    printfxn(car1);
}
void printfxn(CAR car){
    std::cout<<&car<<'\n';
    std::cout<<"The model of car 1 is : "<<car.model<<'\n';
    std::cout<<"The year of car 1 is : "<<car.year<<'\n';
}
// IMP POINT; IF U WANT TO MAKE CHANGES IN VARIABLES OF ORIGINAL THEN IT IS NEEDED TO PASS MEMORY OPERATOR