#include<iostream>

int main(){

    std::string cup1="cofee powder";
    std::string cup2="Milk";
    std::string temp;

    temp=cup1;
    cup1=cup2;
    cup2=temp;

    std::cout<<cup1<<'\n';
    std::cout<<cup2<<'\n';

    // this is a prime example of pass by value where no modification of original data is done

}

#include<iostream>


void swap(std::string &bhanda1,std::string &bhanda2,std::string temp);
int main(){

    std::string bhanda1="caha powder";
    std::string bhanda2="milk";
    std::string temp;
    swap(bhanda1,bhanda2,temp);

      std::cout<<bhanda1<<'\n';
    std::cout<<bhanda2<<'\n';


}
void swap(std::string &bhanda1,std::string &bhanda2,std::string temp){
    
    temp=bhanda1;
    bhanda1=bhanda2;
    bhanda2=temp;

  
}
// By passing variables by reference i.e is &, the function works with the latest values of bhanda1 and bhanda2 and can modify them directly.

// Use pass-by-value for small data types and when you don't need to modify the original data.
// // Use pass-by-reference when you need to modify the original data, work with large objects, or return multiple values from a function