#include <iostream>
#include <cstdlib>
#include <ctime>

int main() {
    using namespace std;
    srand(std::time(0));

    // Generate a random number in the range [1, 100]
    int random_number = std::rand() % 100 +1;
    int guess,attempts=0;

    do
    {
       cout<<"Guess any number between 1 to 100\n";
       cin>>guess;
       if (guess>random_number)
       {
        cout<<"Please choose a smaller number\n";
       }
       else if (guess<random_number)
       {
        cout<<"Please choose a bigger number\n";
       }
       
       attempts+=1;
    } while (guess!=random_number);

    cout<<"CONGRATULATION YOU WON THE GAME IN :"<<attempts<<"ATTEMPTS"<<std::endl;

    return 0;
    

}