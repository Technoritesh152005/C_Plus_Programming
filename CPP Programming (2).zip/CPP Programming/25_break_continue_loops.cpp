#include<iostream>

int main(){
    for (int i = 0; i < 30; i++){
        if (i==25)
    {
        break;
        // break statement if applied exits the loop
        // continue;
        // if continue used it skips the ongoing condition iteration
    }
    std::cout<<i<<'\n';
    }
    
    

}