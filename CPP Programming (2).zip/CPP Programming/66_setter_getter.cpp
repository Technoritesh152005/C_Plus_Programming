#include<iostream>

class Stove{

    // the attribute is done private which cannot be accesed or modified
   private:
    int temperature=0;

    // A getter is a method used to read or access an attribute's value, but it doesn't inherently prevent modification. It simply provides controlled access to an attribute.

    public:
    // after get name can be used anything,same for set
    int   getTemperature(){
    return temperature;
   }
    // The setter method is used to set a value, not to retrieve it, so you can't use it directly in a cout statement
   void setTemperature(int temperature){

        this->temperature=temperature;
        
   }
};
int main(){

    Stove stove1;
    // stove1.temperature=1000;
    // due to public access modifier we can easily modify the attribute so dicovery of getter and setter happend
    stove1.getTemperature();
    stove1.setTemperature(45);
  

    std::cout<<stove1.getTemperature()<<'\n';
}

// A getter is a method in a class that allows you to access (or "get") the value of a private or protected attribute. It provides controlled, read-only access to the attribute without allowing it to be modified directly.
// A setter is a method in a class that allows you to modify (or "set") the value of a private or protected attribute. It provides controlled write access to the attribute, ensuring that any modifications are done through this method.

// getter is used to read private attributes and setter to modify those attributes