#include<iostream>

int main(){

    std::string family_members []={"Papa","Mummy","Arnav","Ankita","Golya","Maushi"};

    for (int i = 0; i < sizeof(family_members)/sizeof(std::string); i++)
    {
        std::cout<<family_members[i]<<'\n';
    }
    // this will give access to all elements of array and no need to change size in for loop when some extra value has been added to array
    
}