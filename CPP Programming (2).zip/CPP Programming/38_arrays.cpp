#include<iostream>

int main(){

    // An array is a collection of elements, typically of the same data type, stored at contiguous memory locations. This allows for efficient access and manipulation of the elements using an index. 
    
    // array is a kind of variable that holds multiple values
    // here car act as a array ehre it holds certain value. index in array always starts with zero
    // for array if we are taking value then that value datatype must be provided

    std::string cars[]={"BMW","lambhorgini","Ferrari"};

    std::cout<<cars[0]<<'\n';
    std::cout<<cars[1]<<'\n';
    std::cout<<cars[2]<<'\n'<<'\n';
    // here array has been declared giving its indx 0 where it states the first element of array


    // array declaration when done then size is been given always
    std::string trucks[3];
    trucks[0]="TATA";
    trucks[1]="Ashok leyland";

    std::cout<<trucks[0]<<'\n';
    std::cout<<trucks[1]<<'\n';
    
}