#include<iostream>

int main() {
    using namespace std;
    double balance = 0, deposit = 0, withdraw = 0;
    int choices;
    
    cout << "***************WELCOME TO STATE BANK OF INDIA **************\n\n";
    
    do {
        cout << "Press 1 for balance enquiry\n";
        cout << "Press 2 for deposit\n";
        cout << "Press 3 for withdraw\n";
        cout << "Press 4 for exit the chat\n";
        cin >> choices;

        switch (choices) {
            case 1:
                cout << "The balance in your account is : " << balance << endl;
                break;
            case 2:
                cout << "Enter the amount you want to deposit: ";
                cin >> deposit;
                balance += deposit;
                cout << "The amount has been deposited: " << deposit << '\n';
                cout << "The new balance is : " << balance << '\n';
                break;
            case 3:
                cout << "Enter the amount you need to withdraw: ";
                cin >> withdraw;
                if (balance >= withdraw) {
                    balance -= withdraw;
                    cout << "The amount has been withdrawn: " << withdraw << endl;
                } else {
                    cout << "Insufficient balance\n";
                }
                break;
            case 4:
                cout << "The chat has been exited, thanks for visiting. Please visit again.\n";
                break;
            default:
                cout << "Invalid choice, please try again.\n";
        }
    } while (choices != 4);

    cout << '\n' << '\n';

    return 0;
}
