#include<iostream>

// the class variable must always start with a uppercase character

// constructor : 
// A constructor is a special function in a class that is automatically called when an object of that class is created. It is used to initialize the object's properties or perform any setup necessary. In most programming languages, a constructor has the same name as the class and does not return a value.


class Students{
    public:
    std::string name;
    int age;
    double gpa;
    // when the parameters name is same as attribute then use this-> other if the parameters name are different u can use name=x;
    // it is useful to assign value to attributes using arguments
    Students(std::string name,int age,double gpa){
        this->name=name;
        this->age=age;
        this->gpa=gpa;
    }

};
int main(){

    Students student1("Ritesh",20,8.87);
    std::cout<<student1.name<<'\n';
    std::cout<<student1.age<<'\n';
    std::cout<<student1.gpa<<'\n';

}