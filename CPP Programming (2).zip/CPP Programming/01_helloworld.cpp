#include <iostream>
// This preprocessor directive includes the iostream library, which is necessary for input and output operations.it is also known as header file

int main(){

    std::cout <<"hello this is my first program" << std :: endl;
    // here std stands for standard and cout means character output
    
    std::cout <<"i have started cpp today" << std::endl;
    // here << std::endl; is used to flush the buffer and print the statement to new line

    return 0;
}