#include<iostream>

// here human act as a datatype
// when we defaulty assigned value of name and job then all its variable will have that same name and job or anything

// objects : it is a collection of attributes and methods , where attributes stand for characteristic of that object and method are the functions that object can perform;
class human{
    public:
    std::string name;
    std::string job;
    int age;

    void sleep(){
        std::cout<<"He is sleeping"<<'\n';
    }
    void eating(){
        std::cout<<"A human can eat also"<<'\n';
    }
    void drink(){
    std::cout<<"A human can drink also"<<'\n';
    }
};
    
int main(){

human human1;

    human1.name="Ritesh";
    human1.job="Engineer";
    human1.age=20;

    std::cout<<human1.name<<'\n';
    std::cout<<human1.age<<'\n';

    human1.eating();
    human1.sleep();
}