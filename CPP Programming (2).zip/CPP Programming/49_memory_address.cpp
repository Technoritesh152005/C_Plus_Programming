#include<iostream>

int main(){
    
    // memory adress is denoted by & and it is a memory location if a variable in memory/ram
    int age=21;
    std::string name="Ritesh";
    bool ritesh=true;

    std::cout<<&age<<'\n';
    // 6422520
     std::cout<<&name<<'\n';
    //   6422512
      std::cout<<&ritesh<<'\n';
    //   6422511

}